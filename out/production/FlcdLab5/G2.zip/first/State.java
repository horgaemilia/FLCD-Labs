package first;

public enum State {
    NORMAL,
    ERROR,
    BACK,
    FINAL
}
